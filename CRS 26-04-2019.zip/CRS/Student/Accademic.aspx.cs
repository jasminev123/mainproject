﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRS.Classes;
using System.Data;
using System.IO;
namespace CRS.Student
{
    public partial class Accademic : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_qualification_Click(object sender, EventArgs e)
        {
            lbl_add.Visible = true;
            Panel1.Visible = true;

            lbl_current.Visible = false;
            Panel2.Visible = false;
        }
        protected void btn_saveq_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            AccademicClass sObj = new AccademicClass();
            sObj.Course = DropDownList_course.Text;
            sObj.Specialisation = DropDownList_spe.Text;
            sObj.Instituton = txt_institute.Text;
            sObj.Board = txt_board.Text;
            sObj.Mark = txt_cgpa.Text;
            sObj.Yop = txt_yop.Text;
            sObj.Sid =Convert.ToInt32(Session["stud_id"].ToString());
            

            //File Upload
            string mark = Path.GetFileName(FileUpload_mark.PostedFile.FileName);
            string ext = Path.GetExtension(mark);
            if (ext.ToLower() == ".doc" || ext.ToLower() == ".docx" || ext.ToLower() == ".pdf")
            {
                string srcs = Server.MapPath("~/Uploads") + "/" + mark;
                FileUpload_mark.PostedFile.SaveAs(srcs);
                ViewState["DocPath1"] = "~/Uploads/" + mark;
                sObj.Marklist = Convert.ToString(ViewState["DocPath1"]);
            }
            else
            {
                Response.Write("<script LANGUAGE='JavaScript' >alert('Please select a document file...')</script>");
            }
            sObj.Qualification();

        }

        protected void DropDownList_course_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList_course.SelectedItem.Text.ToString() == "SSLC")

            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("None");
            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "PlusTwo")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Biomaths");
                DropDownList_spe.Items.Add("Computer Science");
                DropDownList_spe.Items.Add("Commerce");

            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "BCA")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Computer Application");
            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "B.sc")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Computer Science");
                DropDownList_spe.Items.Add("Maths");
                DropDownList_spe.Items.Add("Chemistry");
                DropDownList_spe.Items.Add("Physics");
                DropDownList_spe.Items.Add("Botany");
                DropDownList_spe.Items.Add("Zoology");
            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "BBA")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Bussiness Administration");
            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "B.Tech")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Computer Science");
                DropDownList_spe.Items.Add("Mechanical");
                DropDownList_spe.Items.Add("Civil");
                DropDownList_spe.Items.Add("EEE");
                DropDownList_spe.Items.Add("EC");
                DropDownList_spe.Items.Add("Automobile");
            }
        }

        protected void btn_course_Click(object sender, EventArgs e)
        {
            lbl_current.Visible = true;
            Panel2.Visible = true;

            lbl_add.Visible = false;
            Panel1.Visible = false;
        }

        protected void btn_savec_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            AccademicClass sObj = new AccademicClass();
            sObj.Ccourse = DropDownList_ccourse.Text;
            sObj.Cspecialisation = DropDownList_cspe.Text;
            sObj.Sem1 = txt_sem1.Text;
            sObj.Sem2 = txt_sem2.Text;
            sObj.Sem3 = txt_sem3.Text;
            sObj.Sem4 = txt_sem4.Text;
            sObj.Sem5 = txt_sem5.Text;
            sObj.Sem6 = txt_sem6.Text;
            sObj.Sem7 = txt_sem7.Text;
            sObj.Sem8 = txt_sem8.Text;
            sObj.Backlogs = txt_back.Text;
            sObj.Sid = Convert.ToInt32(Session["stud_id"].ToString());

            sObj.InsertCurentcourse();


        }

        protected void DropDownList_ccourse_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList_ccourse.SelectedItem.Text.ToString() == "B.Tech")
            {
                DropDownList_cspe.Items.Clear();
                DropDownList_cspe.Items.Add("Computer Science");
                DropDownList_cspe.Items.Add("Mechanical");
                DropDownList_cspe.Items.Add("Civil");
                DropDownList_cspe.Items.Add("EEE");
                DropDownList_cspe.Items.Add("EC");
                DropDownList_cspe.Items.Add("Automobile");
            }
            else if (DropDownList_ccourse.SelectedItem.Text.ToString() == "MBA")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_cspe.Items.Add("Bussiness Administration");
            }
            else if (DropDownList_ccourse.SelectedItem.Text.ToString() == "MCA")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_cspe.Items.Add("Regular");
                DropDownList_cspe.Items.Add("Lateral Entry");
            }
            else if (DropDownList_ccourse.SelectedItem.Text.ToString() == "M.Tech")
            {
                DropDownList_cspe.Items.Clear();
                DropDownList_cspe.Items.Add("Computer Science");
              
                DropDownList_cspe.Items.Add("Civil");
                
                DropDownList_cspe.Items.Add("EC");
                
            }
        }
        
    }
}