﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRS.Classes;
using System.Data;


namespace CRS.TPO
{
    public partial class ViewCompany : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LoadData();

        }


        private void LoadData()
        {
            DataTable dtReg = new DataTable();
            ViewCompanyClass vcObj = new ViewCompanyClass();
            dtReg = vcObj.ExecuteSelectQueries();
            if (dtReg.Rows.Count > 0)
            {
                gv_company.DataSource = dtReg;
                gv_company.DataBind();
            }

        }

    }
}



