﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CRS.Classes
{
    public class LoginClass
    {
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        private string username;
        private string password;
        private int sid;
        private string type;

        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }
        public int Sid { get => sid; set => sid = value; }
        public string Type { get => type; set => type = value; }

        public int FetchSid()
        {
            OpenConection();
            SqlCommand cmd = new SqlCommand("select S_id from tbl_StudentRegister where S_email='" + username + "' and S_phn='" + password + "'", con);
            object cMax = cmd.ExecuteScalar();
            if(cMax!=DBNull.Value)
            {
                sid = (int)cMax;

            }
            return sid;
            
        }

        public string FetchType()
        {
            OpenConection();
            SqlCommand cmd1 = new SqlCommand("select Type from Login_tbl where Username='" + username + "' and Password='" + password + "'", con);
            object cmax = cmd1.ExecuteScalar();
            if(cmax!=DBNull.Value)
            {
                type = (string)cmax;
            }
            return type;
        }
    }
}