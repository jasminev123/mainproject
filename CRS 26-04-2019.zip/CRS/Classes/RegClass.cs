﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace CRS.Classes
{
    public class RegClass
    {
        private int sid;
        private string sname;
        private string semail;
        private string sphn;
        private string sdept;
        private string sbranch;
        private string login_id;

        private string uname;
        private string pass;

        public string Sname { get => sname; set => sname = value; }
        public string Semail { get => semail; set => semail = value; }
        public string Sdept { get => sdept; set => sdept = value; }
        public string Sphn { get => sphn; set => sphn = value; }
        public string Sbranch { get => sbranch; set => sbranch = value; }
        public int Sid { get => sid; set => sid = value; }

        public string Uname { get => uname; set => uname = value; }
        public string Pass { get => pass; set => pass = value; }
        public string Login_id { get => login_id; set => login_id = value; }

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public void InsertStudent()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(S_id) from tbl_StudentRegister ", con);
            int id;
                object cMax = command.ExecuteScalar();
                if (cMax != DBNull.Value)
                {
                id = (int) cMax;
                id++;
                 }
                else
                {
                 id = 1;
                }


            string qry = "insert into tbl_StudentRegister values ('" + id + "',@sname,@semail,@sphn,@sdept,@sbranch,'" + id + "'); ";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@sname", sname);
            cmd.Parameters.AddWithValue("@semail", semail);
            cmd.Parameters.AddWithValue("@sphn", sphn);
            cmd.Parameters.AddWithValue("@sdept", sdept);
            cmd.Parameters.AddWithValue("@sbranch", sbranch);
            cmd.ExecuteNonQuery();
        }
        public void InsertLogin()
        {
            OpenConection();

            SqlCommand cmd = new SqlCommand("Select max(login_id) from Login_tbl ", con);
            //cmd.Parameters.AddWithValue("@semail", semail);
            //cmd.Parameters.AddWithValue("@sphn", sphn);
            int login_id;
            object cMax = cmd.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                login_id = (int)cMax;
                login_id++;
            }
            else
            {
                login_id = 1;
            }
            string type;
            type = "Student";




            string qry2 = "insert into Login_tbl values ('"+ login_id + "' ,@uname,@pass,@type);";
            SqlCommand cmd2 = new SqlCommand(qry2, con);
            cmd2.Parameters.AddWithValue("@login_id", login_id);
            cmd2.Parameters.AddWithValue("@uname", Uname);
            cmd2.Parameters.AddWithValue("@pass", Pass);
            cmd2.Parameters.AddWithValue("@type", type);
            cmd2.ExecuteNonQuery(); 
        }



    }
}