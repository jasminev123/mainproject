﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using CRS.Classes;


namespace CRS.Common
{
    public partial class login : System.Web.UI.Page
    {
        LoginClass lObj = new LoginClass();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            lObj.Username = txt_usrname.Text.ToString();
            lObj.Password = txt_pswd.Text.ToString();
            int id= lObj.FetchSid();
            Session["stud_id"] = id;
            string type1= lObj.FetchType();
            if(type1=="admin")
            {
                Session["uname"] = txt_usrname.Text.ToString();
                Response.Redirect("~/TPO/StudReg.aspx");
            }
            else if(type1== "Student")
            {
                Session["uname"] = txt_usrname.Text.ToString();
                Response.Redirect("~/Student/CreateProfile.aspx");
            }
            else if(type1== "Company")
            {
                Session["uname"] = txt_usrname.Text.ToString();
                Response.Redirect("~/Company/CompanyReg.aspx");
            }
            else
            {
                lbl_msg.Text = "Wrong username or password. Try again...!!";

            }
           

        }
    }
}