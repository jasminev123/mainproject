﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRS.Classes;
using System.Data;

namespace CRS.Common
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_login_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            LoginClass lObj = new LoginClass();
            lObj.Uname = txt_usrname.Text;
            lObj.Pass = txt_pswd.Text;
            
            dtReg = lObj.ExecuteSelectQueries();
            Session["sid"] = lObj.Sid;
            if (dtReg.Rows.Count > 0)
            {
               string type1;

                type1 =(string) dtReg.Rows[0]["Type"];
                if (type1 == "admin")
                {
                    //Label1.Text = "Login Success...!";
                    Session["admin"] = txt_usrname.Text;
                   Response.Redirect("~/TPO/StudReg.aspx");
                }
                if (type1 == "Student")
                {
                    Session["student"] = txt_usrname.Text;
                    lbl_msg.Text = "Login Success...!";
                    Response.Redirect("~/Student/CreateProfile.aspx");
                }
                if (type1 == "Company")
                {
                    Session["company"] = txt_usrname.Text;
                    lbl_msg.Text = "Login Success...!";
                    Response.Redirect("~/Company/CompanyReg.aspx");
                }
                

            }
            else
            {
                lbl_msg.Text = "Wrong username or password. Try again...!!";
            }

        }
    }
}