﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace CRS.Classes
{
    public class CompanyRegClass
    {
        private int c_id;
        private string c_name;
        private string c_place;
        private string c_email;
        private string c_phno;
        private string c_hrname;
        private string c_website;
        private string c_usrname;
        private string c_password;
        

        private int login_id;
        private string uname;
        private string pass;

        public string C_name { get => c_name; set => c_name = value; }
        public string C_place { get => c_place; set => c_place = value; }
        public string C_email { get => c_email; set => c_email = value; }
        public string C_phno { get => c_phno; set => c_phno = value; }
        public string C_hrname { get => c_hrname; set => c_hrname = value; }
        public string C_usrname { get => c_usrname; set => c_usrname = value; }
        public string C_password { get => c_password; set => c_password = value; }
        
        public int C_id { get => c_id; set => c_id = value; }
       
        public string Uname { get => uname; set => uname = value; }
        public string Pass { get => pass; set => pass = value; }
        public string C_website { get => c_website; set => c_website = value; }
        public int Login_id { get => login_id; set => login_id = value; }

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        public void InsertCompany()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(c_id) from CompanyRegistration_tbl ", con);
            string s = "Pending";
            int cid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                cid = (int)cMax;
                cid++;
            }
            else
            {
                cid = 1;
            }
            string qry = "insert into CompanyRegistration_tbl values ('" + cid + "',@cname,@cplace,@cemail,@cphno,@chrname,@cwebsite,'" + s + "');";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@cname", c_name);
            cmd.Parameters.AddWithValue("@cplace", c_place);
            cmd.Parameters.AddWithValue("@cemail", c_email);
            cmd.Parameters.AddWithValue("@cphno", c_phno);
            cmd.Parameters.AddWithValue("@chrname", c_hrname);
            cmd.Parameters.AddWithValue("@cwebsite", c_website);
          
           
            cmd.ExecuteNonQuery();
        }

        public void InsertLogin()
        {
            OpenConection();
            SqlCommand cmd = new SqlCommand("Select max(login_id) from Login_tbl ", con);
            //cmd.Parameters.AddWithValue("@semail", semail);
            //cmd.Parameters.AddWithValue("@sphn", sphn);
            int login_id;
            object cMax = cmd.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                login_id = (int)cMax;
                login_id++;
            }
            else
            {
                login_id = 1;
            }

            string type;
            type = "Company";
            
            string qry = "insert into Login_tbl values ('"+login_id+"',@uname,@pass,'" + type + "');";
            SqlCommand cmd1 = new SqlCommand(qry, con);
            cmd1.Parameters.AddWithValue("@login_id", login_id);
            cmd1.Parameters.AddWithValue("@uname", Uname);
            cmd1.Parameters.AddWithValue("@pass", Pass);
           

            cmd1.ExecuteNonQuery();
        }

    }
}