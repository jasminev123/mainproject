﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;


namespace CRS.Classes
{
    public class AccademicClass
    {

        private string course;
        private string specialisation;
        private string instituton;
        private string board;
        private string mark;
        private string yop;
        private string marklist;

        private string ccourse;
        private string cspecialisation;
        private string sem1;
        private string sem2;
        private string sem3;
        private string sem4;
        private string sem5;
        private string sem6;
        private string sem7;
        private string sem8;
        private string backlogs;
        private int sid;

        public string Course { get => course; set => course = value; }
        public string Specialisation { get => specialisation; set => specialisation = value; }
        public string Instituton { get => instituton; set => instituton = value; }
        public string Board { get => board; set => board = value; }
        public string Mark { get => mark; set => mark = value; }
        public string Yop { get => yop; set => yop = value; }
        public string Marklist { get => marklist; set => marklist = value; }

        public string Ccourse { get => ccourse; set => ccourse = value; }
        public string Cspecialisation { get => cspecialisation; set => cspecialisation = value; }
        public string Sem1 { get => sem1; set => sem1 = value; }
        public string Sem2 { get => sem2; set => sem2 = value; }
        public string Sem3 { get => sem3; set => sem3 = value; }
        public string Sem4 { get => sem4; set => sem4 = value; }
        public string Sem5 { get => sem5; set => sem5 = value; }
        public string Sem6 { get => sem6; set => sem6 = value; }
        public string Sem7 { get => sem7; set => sem7 = value; }
        public string Sem8 { get => sem8; set => sem8 = value; }
        public string Backlogs { get => backlogs; set => backlogs = value; }
        public int Sid { get => sid; set => sid = value; }

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;


        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }
        
        public void Qualification()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(qid) from Qualification_tbl ", con);
            int qid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                qid = (int)cMax;
                qid++;
            }
            else
            {
                qid = 1;
            }

            string qry = "insert into Qualification_tbl values ('" + qid + "',@course,@specialisation,@institution,@board,@mark,@yop,@marklist,@sid);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@course", Course);
            cmd.Parameters.AddWithValue("@specialisation", Specialisation);
            cmd.Parameters.AddWithValue("@institution", Instituton);
            cmd.Parameters.AddWithValue("@board", Board);
            cmd.Parameters.AddWithValue("@mark", Mark);
            cmd.Parameters.AddWithValue("@yop", Yop);
            cmd.Parameters.AddWithValue("@marklist", Marklist);
            
            cmd.ExecuteNonQuery();

        }
        public void InsertCurentcourse()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select max(ccid) from CurrentCourse_tbl ", con);
            int ccid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                ccid = (int)cMax;
                ccid++;
            }
            else
            {
                ccid = 1;
            }

            string qry = "insert into CurrentCourse_tbl ('" + ccid + "',@ccourse,@cspecialization,@sem1,@sem2,@sem3,@sem4,@sem5,@sem6,@sem7,@sem8,@sid);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@ccourse", Ccourse);
            cmd.Parameters.AddWithValue("@cspecialization", Cspecialisation);
            cmd.Parameters.AddWithValue("@sem1", Sem1);
            cmd.Parameters.AddWithValue("@sem2", Sem2);
            cmd.Parameters.AddWithValue("@sem3", Sem3);
            cmd.Parameters.AddWithValue("@sem4", Sem4);
            cmd.Parameters.AddWithValue("@sem5", Sem5);
            cmd.Parameters.AddWithValue("@sem6", Sem6);
            cmd.Parameters.AddWithValue("@sem7", Sem7);
            cmd.Parameters.AddWithValue("@sem8", Sem8);
            cmd.Parameters.AddWithValue("@backlogs", Backlogs);

            cmd.ExecuteNonQuery();

        }

    }
}