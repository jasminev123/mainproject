﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRS.Classes;
using System.Data;



namespace CRS.Company
{
    public partial class vaconcy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            VacancyClass vObj = new VacancyClass();
            vObj.Novaconcy = txt_novaconcy.Text;
            vObj.Place = txt_place.Text;
            vObj.Driveplace = txt_drivepl.Text;
            vObj.Drivetime = txt_drivetime.Text;
            vObj.Date = txt_drivedate.Text;
            vObj.Criteria = txt_criteria.Text;
            vObj.InsertVaconcy();
      
           
      
        }

        
    }
}