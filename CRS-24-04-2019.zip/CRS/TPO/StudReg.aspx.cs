﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRS.Classes;
using System.Data;

namespace CRS.TPO
{
    public partial class StudReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            RegClass rObj = new RegClass();
            rObj.Sname = txt_name.Text;
            rObj.Semail = txt_email.Text;
            rObj.Sphn = TextBox1.Text;
            rObj.Sdept = combo.SelectedItem.Text;
            rObj.Sbranch = combo_branch.SelectedItem.Text;

            rObj.Uname = txt_email.Text;
            rObj.Pass = TextBox1.Text;
            rObj.InsertStudent();
            rObj.InsertLogin();


        }


    }
}