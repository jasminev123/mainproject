﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;

namespace CRS.Classes
{
    public class VacancyClass
    {
        private int vaconcy_id;
        private string novaconcy;
        private string place;
        //private string qulification;
        private string driveplace;
        private string drivetime;
        private string date;


        public int Vaconcy_id { get => vaconcy_id; set => vaconcy_id = value; }
        public string Novaconcy { get => novaconcy; set => novaconcy = value; }
        public string Place { get => place; set => place = value; }
       // public string Qulification { get => qulification; set => qulification = value; }
        public string Driveplace { get => driveplace; set => driveplace = value; }
        public string Drivetime { get => drivetime; set => drivetime = value; }
        public string Date { get => date; set => date = value; }

        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;


        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }

        public void ExecuteQueries(string Query_)
        {
            // Whenever you want to execute a query, like an insert, update or delete
            //query then simply call this function 
            //using the object of a class and pass your query to the function
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public void InsertVaconcy()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("select max(vaconcy_id) from Company_vaconcy_tbl ", con);
            int vcncyid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                vcncyid = (int)cMax;
                vcncyid++;
            }
            else
            {
                vcncyid = 1;
            }

            string qry = "insert into Company_vaconcy_tbl values ('" + vcncyid + "',@novaconcy,@place,@driveplace,@date,@drivetime);";
            SqlCommand cmd = new SqlCommand(qry, con);
            cmd.Parameters.AddWithValue("@novaconcy", Novaconcy);
            cmd.Parameters.AddWithValue("@place", Place);
            //cmd.Parameters.AddWithValue("@qulification", Qulification);
            cmd.Parameters.AddWithValue("@driveplace", Driveplace);
            cmd.Parameters.AddWithValue("@drivetime", drivetime);
            cmd.Parameters.AddWithValue("@date", date);

            cmd.ExecuteNonQuery();

        }


    }
}