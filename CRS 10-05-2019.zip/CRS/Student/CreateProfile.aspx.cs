﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using CRS.Classes;


namespace CRS.Student
{
    public partial class CreateProfile : System.Web.UI.Page
    {
        ProfileClass update = new ProfileClass();
        DataTable dt = new DataTable();


        protected void Page_Load(object sender, EventArgs e)
        {
           // if (!IsPostBack)
            {
                //   int id = Convert.ToInt32(Session["sid"].ToString());
                // Response.Write(id);
                //update.Sid = id;
                //Loaddata();
                //DataTable dt = new DataTable();
                //dt = update.ExecuteSelectQueries();
                //if (dt.Rows.Count > 0)
                //{
                //    txt_name.Text =Convert.ToString(dt.Rows[0]["S_name"]);
                //    txt_email.Text = dt.Rows[0]["S_email"].ToString();
                //    txt_phno.Text = dt.Rows[0]["S_phn"].ToString();
                //}
                /*int rcount = dt.Rows.Count;

                for (int i = 0; i < rcount; i++) {
                    string uid = dt.Rows[i]["S_id"].ToString();
                    if (uid == Session["sid"].ToString())
                    {
                        txt_name.Text = dt.Rows[i]["S_name"].ToString();
                        txt_email.Text = dt.Rows[i]["S_email"].ToString();
                        txt_phno.Text = dt.Rows[i]["S_phn"].ToString();
                    }
                }*/
                //}
                /*---------------------------------------------*/

                int id = Convert.ToInt32(Session["sid"]);
                update.Sid = id;
                Response.Write(id);
                dt = update.ExecuteSelectQueries();
                int rcount = dt.Rows.Count;

                for (int i = 0; i < rcount; i++)
                {
                    string uid = dt.Rows[i]["S_id"].ToString();
                    if (uid == Session["sid"].ToString())
                    {
                        txt_name.Text = dt.Rows[i]["S_name"].ToString();
                        txt_email.Text = dt.Rows[i]["S_email"].ToString();
                        txt_phno.Text = dt.Rows[i]["S_phn"].ToString();
                    }
                }


            
            //public void Loaddata()
            //{
            //    DataTable dtReg = new DataTable();
            //    update.Sid= Convert.ToInt32(Session["sid"]);
            //    //update.Uid = Convert.ToInt32(Session["userid"]);
            //    dtReg = update.disply();
            //    if (dtReg.Rows.Count > 0)
            //    {
            //        txt_name.Text = Convert.ToString(dtReg.Rows[0]["S_name"]);
            //        txt_email.Text = Convert.ToString(dtReg.Rows[0]["S_email"]);
            //        txt_phno.Text = Convert.ToString(dtReg.Rows[0]["S_phn"]);

               }

            }
            /*-------------------------------------------*/

            public void Loaddata()
            {
                DataTable dtReg = new DataTable();
                //updata.Uid = Convert.ToInt32(Session["userid"]);
                dtReg = update.disply();
                if (dtReg.Rows.Count > 0)
                {
                    txt_name.Text = Convert.ToString(dtReg.Rows[0]["name"]);
                    txt_email.Text = Convert.ToString(dtReg.Rows[0]["email"]);
                    txt_phno.Text = Convert.ToString(dtReg.Rows[0]["phno"]);

                }

            }



            protected void Button1_Click(object sender, EventArgs e)
        {
            if (radio_female.Checked)
            {
                update.S_gender = radio_female.Text;
            }
            else
            {
                update.S_gender = radio_m.Text;
            }
            // updata.Uid = Convert.ToInt32(Session["userid"]);
            update.S_adno = txt_adno.Text;
            update.S_phno = txt_phno.Text;
            update.S_email = txt_email.Text;
            update.S_dob = txt_dob.Text;
            update.S_name = txt_name.Text;
            update.S_address = txt_address.Text;
            update.S_locality = txt_locality.Text;
            update.S_town = txt_town.Text;
            update.S_pincode = txt_pincode.Text;
            update.S_state = txt_state.Text;
            update.S_district = txt_district.Text;
            update.disply();
            update.InsertProfile();
            Response.Redirect("~/Student/Accademic.aspx");
        }

        protected void radio_m_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}