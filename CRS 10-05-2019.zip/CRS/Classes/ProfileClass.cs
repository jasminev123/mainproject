﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace CRS.Classes
{
    public class ProfileClass
    {
        private int pid;
        private string s_name;
        private string s_adno;
        private string s_dob;
        private string s_gender;
        private string s_address;
        private string s_locality;
        private string s_town;
        private string s_pincode;
        private string s_state;
        private string s_district;
        private string s_phno;
        private string s_email;
        private int sid;



        public string S_name { get => s_name; set => s_name = value; }
        public string S_dob { get => s_dob; set => s_dob = value; }
        public string S_gender { get => s_gender; set => s_gender = value; }
        public string S_address { get => s_address; set => s_address = value; }
        public string S_locality { get => s_locality; set => s_locality = value; }
        public string S_town { get => s_town; set => s_town = value; }
        public string S_pincode { get => s_pincode; set => s_pincode = value; }
        public string S_state { get => s_state; set => s_state = value; }
        public string S_phno { get => s_phno; set => s_phno = value; }
        public string S_email { get => s_email; set => s_email = value; }
        public string S_district { get => s_district; set => s_district = value; }
        public string S_adno { get => s_adno; set => s_adno = value; }
        public int Pid { get => pid; set => pid = value; }
        public int Sid { get => sid; set => sid = value; }

       
        string ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["myConn"].ConnectionString;
        SqlConnection con;

        public void OpenConection()
        {
            con = new SqlConnection(ConnectionString);
            con.Open();
        }

        public void CloseConnection()
        {
            con.Close();
        }
        public void ExecuteQueries(string Query_)
        {
            
            OpenConection();
            SqlCommand cmd = new SqlCommand(Query_, con);
            cmd.ExecuteNonQuery();
        }

        public DataTable ExecuteSelectQueries()
        {
            DataTable dtReg = new DataTable();

            OpenConection();
            //SqlCommand cmd2 = new SqlCommand("select * from tbl_StudentRegister where S_id=@sid ", con);
            SqlCommand cmd2 = new SqlCommand("select * from tbl_StudentRegister where S_id=@sid ", con);
            cmd2.Parameters.AddWithValue("@sid", Sid);
            //cmd2.Parameters.AddWithValue("@sname",S_name);
            //cmd2.Parameters.AddWithValue("@semail", S_email);
            //cmd2.Parameters.AddWithValue("@sphno", S_phno);

            cmd2.ExecuteNonQuery();
            CloseConnection();


            SqlDataAdapter da = new SqlDataAdapter(cmd2);
            da.Fill(dtReg);
           
            return dtReg;

        }
        public DataTable disply()
        {
            
            OpenConection();

            //String qry = "select * from tbl_StudentRegister";
            //SqlCommand cmd = new SqlCommand(qry, con);
            ////cmd.Parameters.AddWithValue("@uid", Uid);
            //cmd.ExecuteNonQuery();
            //CloseConnection();
            //SqlDataAdapter da = new SqlDataAdapter(cmd);
            //da.Fill(dtReg);

            //CloseConnection();
            //return dtReg;
            DataTable dtReg = new DataTable();
            SqlCommand cmd = new SqlCommand("select * from tbl_StudentRegister where S_id=@sid ",con);
            cmd.Parameters.AddWithValue("@sid", Sid);
            //cmd.Parameters.AddWithValue("@sname", S_name);
            //cmd.Parameters.AddWithValue("@semail", S_email);
            //cmd.Parameters.AddWithValue("@sphno", S_phno);

            cmd.ExecuteNonQuery();
            //CloseConnection();
           
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            da.Fill(dtReg);
            CloseConnection();
            return dtReg;




        }
        public void InsertProfile()
        {
            OpenConection();
            SqlCommand command = new SqlCommand("Select S_id from tbl_StudentRegister where S_email=@email", con);

        command.Parameters.AddWithValue("@email", S_email);
            
            int sid;
            object cMax = command.ExecuteScalar();
            if (cMax != DBNull.Value)
            {
                sid = (int)cMax;
                sid++;
            }
            else
            {
                sid = 1;
            }

            SqlCommand cmd = new SqlCommand("Select max(P_id) from Profile_tbl ", con);

            object cMax1 = cmd.ExecuteScalar();
            if (cMax1 != DBNull.Value)
            {
                pid = (int)cMax1;
                pid++;
            }
            else
            {
                pid = 1;
            }
            string qry = "insert into Profile_tbl values ('" + pid + "',@sadno,@sname,@sdob,@sgender,@saddress,@slocality,@stown,@spincode,@sstate,@sdistrict,@phno,@semail,'" + Sid + "');";
            SqlCommand cmd1 = new SqlCommand(qry, con);

            cmd1.Parameters.AddWithValue("@sadno", S_adno);
            cmd1.Parameters.AddWithValue("@sname", S_name);
            cmd1.Parameters.AddWithValue("@sdob", S_dob);
            cmd1.Parameters.AddWithValue("@sgender", S_gender);
            cmd1.Parameters.AddWithValue("@saddress", S_address);
            cmd1.Parameters.AddWithValue("@slocality", S_locality);
            cmd1.Parameters.AddWithValue("@stown", S_town);
            cmd1.Parameters.AddWithValue("@spincode", S_pincode);
            cmd1.Parameters.AddWithValue("@sstate", S_state);
            cmd1.Parameters.AddWithValue("@sdistrict", S_district);
            cmd1.Parameters.AddWithValue("@phno", S_phno);
            cmd1.Parameters.AddWithValue("@semail", S_email);
            cmd1.ExecuteNonQuery();
        }
    }
}