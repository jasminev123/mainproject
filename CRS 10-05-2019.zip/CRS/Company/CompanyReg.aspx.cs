﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRS.Classes;
using System.Data;
namespace CRS.Company
{
    public partial class CompanyReg : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btn_reg_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            CompanyRegClass cObj = new CompanyRegClass();
            
            cObj.C_name = txt_cname.Text;
            cObj.C_place = txt_cplace.Text;
            cObj.C_email = txt_cemail.Text;
            cObj.C_phno = txt_cphno.Text;
            cObj.C_hrname = txt_chrname.Text;
            cObj.C_website = txt_cwebsite.Text;
            
            

            cObj.Uname = txt_cuname.Text;
            cObj.Pass = txt_cpas.Text;
            cObj.InsertCompany();
            cObj.InsertLogin();
        }
    }
}