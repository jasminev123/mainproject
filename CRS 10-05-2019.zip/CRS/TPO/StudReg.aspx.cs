﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CRS.Classes;
using System.Data;
using System.IO;
using System.Net;
using System.Net.Mail;
using System.Drawing;


namespace CRS.TPO
{
    public partial class StudReg : System.Web.UI.Page
    {
        

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataTable dtReg = new DataTable();
            RegClass rObj = new RegClass();
            rObj.Sname = txt_name.Text;
            rObj.Semail = txt_email.Text;
            rObj.Sphn = TextBox1.Text;
            rObj.Sdept = combo.SelectedItem.Text;
            rObj.Sbranch = combo_branch.SelectedItem.Text;

            rObj.Uname = txt_email.Text;
            rObj.Pass = TextBox1.Text;
            rObj.InsertStudent();
            rObj.InsertLogin();

            //mail

            string email = "";
            //string username = "";
            //string password = "";
            DataTable dt1 = new DataTable();
            dt1 = rObj.SendEmail();
            if (dt1.Rows.Count > 0)
            {
                email = dt1.Rows[0]["S_email"].ToString();
                //username = dt1.Rows[0]["Username"].ToString();
                //password = dt1.Rows[0]["Password"].ToString();


            }


            using (StringWriter sw = new StringWriter())
            {
                using (HtmlTextWriter hw = new HtmlTextWriter(sw))
                {
                    //DetailsView1.RenderControl(hw);
                    StringReader sr = new StringReader(sw.ToString());
                    MailMessage msg1 = new MailMessage();
                    msg1.From = new MailAddress("sjcettposjcet@gmail.com");
                    msg1.To.Add(email);
                    msg1.Subject = "Your Password";
                    msg1.Body = string.Format("Hello Students");

                    msg1.IsBodyHtml = true;

                    NetworkCredential login = new NetworkCredential("sjcettposjcet@gmail.com", "123@abcd");

                    SmtpClient client = new SmtpClient("smtp.gmail.com");
                    client.EnableSsl = true;
                    client.UseDefaultCredentials = false;
                    client.Credentials = login;
                    client.Send(msg1);
                    // lblMessage.Text = "Email Sent Successfully";  
                    // lblMessage.ForeColor = System.Drawing.Color.ForestGreen;  
                    Response.Write("<script>alert('Mail sent successfully')</script>");
                }
            }


        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}