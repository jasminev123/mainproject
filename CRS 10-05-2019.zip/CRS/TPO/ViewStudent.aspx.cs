﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace CRS.TPO
{
    public partial class ViewStudent : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList_course.SelectedItem.Text.ToString() == "MCA")

            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Regular");
                DropDownList_spe.Items.Add("Lateral");
            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "MBA")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Bussines Administration");
            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "M.Tech")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Civil");
                DropDownList_spe.Items.Add("Computer Science");
                DropDownList_spe.Items.Add("EEE");
            }
            else if (DropDownList_course.SelectedItem.Text.ToString() == "B.Tech")
            {
                DropDownList_spe.Items.Clear();
                DropDownList_spe.Items.Add("Civil");
                DropDownList_spe.Items.Add("Computer Science");
                DropDownList_spe.Items.Add("EEE");
                DropDownList_spe.Items.Add("Mechanical");
                DropDownList_spe.Items.Add("EC");

            }

        }
    }
}